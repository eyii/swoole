<?php
return array(
    'base_dir' => WEBPATH . '/uploads/',
    'base_url' => '/uploads/',
);