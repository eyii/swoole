<?php
$redis['master'] = array(
    'host' => "redis",
);
return $redis;