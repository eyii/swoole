<?php
define('BASE_URL', 'http://www.swoole.com/');
return array(
    'get_user_info' => BASE_URL . 'api/get_user_info/',
    'passport' => BASE_URL.'/page/login/',
);