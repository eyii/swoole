var webim = {
    'server' : 'ws://im.swoole.com:9503'
}