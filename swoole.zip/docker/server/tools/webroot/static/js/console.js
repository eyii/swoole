if (!console) {
    var console = {};
    console.log = function (str) {};
    console.dir = function (str) {};
}