1. Tell us your PHP version(`php -v`)

`TODO`

2. Tell us your Swoole version(`php --ri swoole`)

`TODO`

3. Tell us your `Laravel`/`Lumen` version(check composer.json & composer.lock)

`TODO`

4. Detail description about this issue(error/log)

`TODO`

5. Give us a `reproducible` code block and `steps`

```PHP
//TODO: Your code
```
