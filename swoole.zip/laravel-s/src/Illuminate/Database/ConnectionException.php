<?php

namespace Hhxsv5\LaravelS\Illuminate\Database;

class ConnectionException extends \Exception
{

}