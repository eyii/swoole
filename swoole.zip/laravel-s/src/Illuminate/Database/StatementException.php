<?php

namespace Hhxsv5\LaravelS\Illuminate\Database;

class StatementException extends \Exception
{

}